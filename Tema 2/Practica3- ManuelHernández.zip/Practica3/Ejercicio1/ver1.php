<?php
    highlight_file("ejercicio1.php");
?>