<?php
    highlight_file("ejercicio2.php");
?>