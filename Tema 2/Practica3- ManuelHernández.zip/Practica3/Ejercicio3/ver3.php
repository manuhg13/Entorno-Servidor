<?php
    highlight_file("ejercicio3.php");
?>