<?php
    highlight_file("ejercicio4.php");
?>