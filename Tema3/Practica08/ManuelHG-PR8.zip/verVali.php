<?php
    highlight_file("validador.php")
?>