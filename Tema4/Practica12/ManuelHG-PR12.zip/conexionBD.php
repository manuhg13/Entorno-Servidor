<?php
    define('USER', 'manu');
    define('PASS', 'manu');
    define('BBDD', 'cine');

?>