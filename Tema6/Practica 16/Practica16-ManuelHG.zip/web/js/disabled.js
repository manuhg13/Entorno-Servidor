window.location.hash="no-back-button";
window.location.hash="Again-No-back-button";
window.onchange=function() {
    window.location.hash="no-back-button";
};